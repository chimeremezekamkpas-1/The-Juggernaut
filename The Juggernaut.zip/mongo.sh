npm init -y
npm install express cors mongoose